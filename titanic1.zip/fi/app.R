# Load necessary libraries
library(shiny)
library(shinydashboard)
library(DT)
library(dplyr)

# Charger le modèle au démarrage du serveur
model <- readRDS("/Users/mouss/Documents/fi/titanic.rds")

# Read the Titanic dataset
Titanic <- read.csv("C:/Users/mouss/Downloads/archive6/Titanic.csv")
numeric_vars <- Titanic %>% select_if(is.numeric)

# Define UI for the application
ui <- dashboardPage(
  dashboardHeader(title = "Prediction du Titanic"),
  dashboardSidebar(
    selectInput('var', 'Choisir un graphique', choices = c("Histogramme", "Nuage de points", "Corrélation")),
    selectInput('var1', 'Choisir une variable', choices = names(numeric_vars)),
    conditionalPanel(
      condition = "input.var == 'Nuage de points'",
      selectInput('var2', 'Choisir une autre variable', choices = names(numeric_vars))
    )
  ),
  dashboardBody(
    tabsetPanel(
      tabPanel("Data", DTOutput('data')),
      tabPanel(
        'Graphique', 
        conditionalPanel(
          condition = "input.var == 'Histogramme'",
          plotOutput('hist')
        ),
        conditionalPanel(
          condition = "input.var == 'Nuage de points'",
          plotOutput('nuage')
        )
      ),
      tabPanel("Statistique", verbatimTextOutput('stat')),
      tabPanel("Prediction", 
               verbatimTextOutput('stat1'), 
               tabName = 'feature', 
               fluidRow(
                 box(valueBoxOutput("score")),
                 
                 box(selectInput("sex", 'Choisir le sexe svp', choices = c("male", "female")))
               ),
               
               fluidRow(
                 box(
                   numericInput("age", "Donner votre âge", value = 10, min = 10, step = 1),
                   
                 ),
                 box(
                   numericInput("sibsp", "Donner votre sibsp", value = 1, min = 0, step = 1)
                     
                 )
               ),
               
               fluidRow(
                 box(
                   numericInput("parch", "Donner votre parch", value = 0, min = 0, step = 1),
                 ),
                 
                 box(
                   numericInput("fare", "Donner votre fare", value = 10, min = 0, step = 1)
                  )
               ),
               
               fluidRow(
                 box(
                   selectInput("embarked", 'Embarked', choices = c("C", "S", "Q")),
                   
                 ),
                 box(
                   selectInput("class", 'Choisir la classe', choices = c("First", "Second", "Third"))
                     
                  )
               
               ),
               
               fluidRow(
                 box(
                   selectInput("who", 'Qui êtes-vous ?', choices = c("child", "woman", "man")),
                   
                 ),
                 
                 box(
                   checkboxInput("alone", 'Alone', value = TRUE)
                 )
               ),
      )
    )
  )
)

# Define server logic
server <- function(input, output) {
  # Reactive function for prediction
  prediction <- reactive({
    predict(model, newdata = data.frame(
      sex = input$sex,
      age = input$age,
      sibsp = input$sibsp,
      parch = input$parch,
      fare = input$fare,
      embarked = input$embarked,
      class = input$class,
      who = input$who,
      alone = input$alone
    ), type = "response")  # Adjust 'type' based on your model
  })
  
  prediction_label <- reactive({
    ifelse(prediction() < 0.5, "Survivre", "Non survivre")  # Adjust threshold if necessary
  })
  
  # Render value box for prediction score
  output$score <- renderValueBox({
    valueBox(
      paste0("Score: ", round(prediction(), 2)),
      subtitle = prediction_label(),
      color = ifelse(prediction() < 0.5, "green", "red")
    )
  })
  
  # Render histogram plot
  output$hist <- renderPlot({
    hist(Titanic[[input$var1]], xlab = input$var1, main = paste("Histogramme de", input$var1), col='blue')
  })
  
  # Render scatter plot
  output$nuage <- renderPlot({
    plot(Titanic[[input$var1]], Titanic[[input$var2]], xlab = input$var1, ylab = input$var2, main = "Nuage de points", col='green')
  })
  
  # Render summary statistics
  output$stat <- renderPrint({
    summary(Titanic)
  })
  
  # Render data table
  output$data <- renderDT({
    datatable(Titanic)
  })
}


# Run the application
shinyApp(ui = ui, server = server)

