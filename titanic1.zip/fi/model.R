# Charger les bibliothèques nécessaires
library(caret)
library(glmnet)

# Lire les données
titanic <- read.csv("C:/Users/mouss/Downloads/archive6/Titanic.csv", stringsAsFactors = TRUE)

# Vérifier la structure des données
str(titanic)

# Supprimer les lignes avec des valeurs manquantes
titanic1 <- na.omit(titanic)
# Diviser les données en ensembles d'entraînement (70%) et de test (30%) de manière aléatoire
set.seed(123)  # Pour la reproductibilité
train_index <- sample(1:nrow(titanic1), 0.7 * nrow(titanic1))
train_data <- titanic1[train_index, ]
test_data <- titanic1[-train_index, ]
# Entraîner un modèle de régression logistique
model <- glm(survived ~ ., data = train_data, family = "binomial")

# Faire des prédictions sur l'ensemble de test
predictions <- predict(model, newdata = test_data, type = "response")
predicted_classes <- ifelse(predictions > 0.5, 1, 0)

# Évaluer les performances du modèle
conf_matrix <- confusionMatrix(factor(predicted_classes), factor(test_data$survived))
conf_matrix

# Afficher les métriques d'évaluation
conf_matrix$overall["Accuracy"]
conf_matrix$byClass["Recall"]
conf_matrix$byClass["Precision"]
# Enregistrer le modèle
save(model, file = "titanic.RData")

